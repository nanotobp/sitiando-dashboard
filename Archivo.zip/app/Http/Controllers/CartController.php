public function add(Request $request, CartService $cartService)
{
    $request->validate([
        'product_id' => 'required|integer|exists:products,id',
        'qty'        => 'nullable|integer|min:1',
    ]);

    $user = $request->user(); // asumimos user logueado por ahora

    $cart = $cartService->addItem(
        $user,
        (int) $request->input('product_id'),
        (int) $request->input('qty', 1)
    );

    return back()->with('success', 'Producto agregado al carrito.');
}
