<?php

return [
    'public_key'  => env('BANCARD_PUBLIC_KEY'),
    'private_key' => env('BANCARD_PRIVATE_KEY'),
];
