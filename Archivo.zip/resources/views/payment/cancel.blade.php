@extends('layouts.dashboard')

@section('content')
<div class="content-wrapper">
    <div class="content-inner">
        <div class="card" style="padding:30px; text-align:center;">
            <h1 class="title">Pago cancelado ❌</h1>
            <p class="subtitle-text">No se pudo completar la operación.</p>
        </div>
    </div>
</div>
@endsection
