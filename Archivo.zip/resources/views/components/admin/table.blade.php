<div class="table-card card shadow-sm border-0 rounded-xl overflow-hidden">
    <table class="table">
        <thead>
            <tr>
                {{ $head }}
            </tr>
        </thead>

        <tbody>
            {{ $slot }}
        </tbody>
    </table>
</div>
