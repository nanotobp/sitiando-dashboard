Route::get('/', function () {
    return view('dashboard.index');
});
