<a href="{{ route('admin.users.editRole', $user->id) }}" class="btn btn-primary btn-sm">
    Cambiar Rol
</a>

<a href="{{ route('admin.users.permissions', $user->id) }}" class="btn btn-secondary btn-sm">
    Ver Permisos
</a>
